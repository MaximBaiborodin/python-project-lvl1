from brain_games.games.is_even import even_game


def main():
    even_game()
