from brain_games.games.calc import calc_game


def main():
    calc_game()
